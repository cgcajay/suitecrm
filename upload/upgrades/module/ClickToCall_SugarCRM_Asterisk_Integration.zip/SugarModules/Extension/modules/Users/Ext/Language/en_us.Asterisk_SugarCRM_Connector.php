<?php

if (!isset($mod_strings)) { $mod_strings = array(); }
$mod_strings['LBL_PHONEEXTENSION'] = 'Asterisk Extension';
$mod_strings['LBL_ASTERISK'] = 'Asterisk IP';
$mod_strings['LBL_DIALOUTPREFIX'] = 'DialOut Channel';
$mod_strings['LBL_DIALPLAN'] = 'Dial Plan';
$mod_strings['LBL_SHOWCLICKTOCALL'] = 'Show dial icon for calling';




?>
