<?php 

if (!isset($mod_strings)) { $mod_strings = array(); }

    $mod_strings['LBL_ASTERISKGROUP_TITLE'] = 'SugarCRM Asterisk Configuration - TechExtensions';
    $mod_strings['LBL_ASTERISKGROUP_DESC'] = 'Developed By - TechExtensions Team';
    $mod_strings['LBL_ASTERISK_CONFIGURATION_TITLE'] = 'SugarCRM Asterisk Configuration';
    $mod_strings['LBL_CONFIGURATION_DESC'] = 'Configure to use Asterisk Features in CRM';
    $mod_strings['LBL_ACTIVATION_TITLE'] = 'SugarCRM Asterisk Activation';
    $mod_strings['LBL_ACTIVATION_DESC'] = 'Activate SugarCRM Asterisk Add-on';


?>
