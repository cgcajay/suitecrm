<?php
  $entry_point_registry['getCallStatus'] = array(
    'file' => 'custom/modules/Asterisk/include/getCallStatus.php',
    'auth' => true
  );
 ?>
