<?php

$GLOBALS['app_list_strings']['host_list']=array (
  '' => '',
  );
