Steps To install SugarCRM Asterisk Integration.

1) Install Sugar Asterisk Module Provided by TechExtension using module loader.
2) Go to Admin panel and Activate the license.
3) Go to Admin panel and Configure the Asterisk IP and related settings.
4) Go to User profile and edit user profile.
5) Add Extension number assigned to user for enable incoming and outgoingrom CRM.

