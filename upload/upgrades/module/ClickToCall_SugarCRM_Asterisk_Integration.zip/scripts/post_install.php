<?php

if(!defined('sugarEntry'))define('sugarEntry', true);

function post_install() {
require('config.php');
$url = $sugar_config['site_url'];

require_once 'modules/Configurator/Configurator.php';
require_once('modules/ModuleBuilder/parsers/ParserFactory.php');


foreach (array('editview', 'detailview') as $view) {
	$parser = ParserFactory::getParser($view, 'Users');
	if (!isset($parser->_viewdefs['panels']['LBL_CTIUSER_PANEL'])) {
		$parser->_viewdefs['panels']['LBL_CTIUSER_PANEL'] = array(
			array(
				array('name'=> 'phoneextension_c'),
				array('name'=> 'asteriskname_c'),
			),
			array(
				array('name'=> 'showclicktocall_c'),
				array('name'=> 'dialout_prefix_c'),
			),
			array(
				array('name'=> 'dial_plan_c'),
				
			),
			
			
		);
		$parser->handleSave(false);
	}
}


$configurator = new Configurator();
$configurator->loadConfig(); // it will load existing configuration in config variable of object
$configurator->config['asterisk_register_name'] = ""; // declare new or change old value from sugar_config
$configurator->config['asterisk_register_phone'] = ""; // declare new or change old value from sugar_config
$configurator->config['asterisk_register_email'] = ""; // declare new or change old value from sugar_config
$configurator->config['asterisk_register_cname'] = ""; // declare new or change old value from sugar_config


	echo "Module installation in progress. Please wait..........<br><br>";



$configurator->saveConfig();
if( preg_match("/^6\.[1-4]/",$GLOBALS['sugar_version'])) 
{
		$User_det_tpl ="custom/modules/Users/DetailView.tpl";
		$fname=fopen($User_det_tpl,"w");
		$fileopenn=file("custom/modules/Working/Users/DetailView.tpl");
		$c = count($fileopenn);
		$str = "";
		for($i=0;$i<$c;$i++)
		{
		$str = $str.$fileopenn[$i];
		}
		//echo $str;
		fwrite($fname,$str);
		fclose($User_det_tpl);
		fclose("custom/modules/Working/Users/DetailView.tpl");
		
		
		$User_edt_tpl ="custom/modules/Users/EditView.tpl";
		$fname=fopen($User_edt_tpl,"w");
		$fileopenn=file("custom/modules/Working/Users/EditView.tpl");
		$c = count($fileopenn);
		$str = "";
		for($i=0;$i<$c;$i++)
		{
		$str = $str.$fileopenn[$i];
		}
		//echo $str;
		fwrite($fname,$str);
		fclose($User_edt_tpl);
		fclose("custom/modules/Working/Users/EditView.tpl");
		
		
		$User_edt_php ="custom/modules/Users/EditView.php";
		$fname=fopen($User_edt_php,"w");
		$fileopenn=file("custom/modules/Working/Users/EditView.php");
		$c = count($fileopenn);
		$str = "";
		for($i=0;$i<$c;$i++)
		{
		$str = $str.$fileopenn[$i];
		}
		//echo $str;
		fwrite($fname,$str);
		fclose($User_edt_php);
		fclose("custom/modules/Working/Users/EditView.php");
		
		
		
		$User_det_php ="custom/modules/Users/DetailView.php";
		$fname=fopen($User_det_php,"w");
		$fileopenn=file("custom/modules/Working/Users/DetailView.php");
		$c = count($fileopenn);
		$str = "";
		for($i=0;$i<$c;$i++)
		{
		$str = $str.$fileopenn[$i];
		}
		//echo $str;
		fwrite($fname,$str);
		fclose($User_det_php);
		fclose("custom/modules/Working/Users/DetailView.php");
		
		
}
require_once("modules/Administration/QuickRepairAndRebuild.php");
$randc = new RepairAndClear();
$randc->repairAndClearAll(array('clearAll'),array(translate('LBL_ALL_MODULES')), $autoexecute,$show_output);

echo "<br><br>Sugar Asterisk Integration Installed Successfully..............</br>";
}
?>
